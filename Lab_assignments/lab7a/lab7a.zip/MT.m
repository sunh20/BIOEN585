function [X,Y,Q,col] = MT(params,tspan,dt,N,d)
% solves for N number of microtubule tracks over time t
% wall diameter d if wall is present

if ~exist('d','var')
    d = NaN;
end

% define needed terms
Dv = params(1);
V_avg = params(2);
Lp = params(3);

R_std = sqrt(2*Dv*dt);
Q_std = sqrt(V_avg*dt/Lp);

% variables - IC = 0
X = nan(length(tspan),N);
Y = nan(length(tspan),N);
Q = nan(length(tspan),N);
col = zeros(length(tspan),N); % keeps track of idxs of collisions
n_collisions = 0;

X(1,:) = 0;
Y(1,:) = 0;
Q(1,:) = 0;

% calculate tracks
for t = 2:length(tspan)
    dQ = normrnd(0,Q_std,[1,N]);
    r = normrnd(V_avg*dt,R_std,[1,N]);
    
    Q(t,:) = Q(t-1,:) + dQ;     % new sigma term
    dx = r.*cos(Q(t,:));
    dy = r.*sin(Q(t,:));
    
    X(t,:) = X(t-1,:) + dx;
    Y(t,:) = Y(t-1,:) + dy;
    
    % recalculate if there is a wall
    idxs = abs(Y(t,:)) > (d/2); % indices where particle passes bounds
    
    if sum(idxs) > 0
        % disp('I hit a wall')
        Q(t,idxs) = 0;                     % reset to zero
        %X(t,idxs) = X(t-1,idxs) + (d/2-Y(t-1,idxs)) ./ ...
        %        sin(Q(t-1,idxs)) .* (cos(Q(t-1,idxs))-1) + r(idxs); % trig
        X(t,idxs) = X(t-1,idxs) + r(idxs);
        Y(t,idxs) = sign(Y(t-1,idxs)).*d/2; % cling to border

        % check that it was done correctly
        if sum(abs(Y(t,:)) > (d/2)) > 1
            disp('something went wrong')
        end  
        
        % check if was real collisions (works only for n = 1 case)        
        if n_collisions == 0  % first collision always real
            n_collisions = n_collisions + 1;
            col(n_collisions,:) = t;  
        else
            prev_collision = col(n_collisions,:);
            Y_diff = abs(Y(prev_collision:t,:)) - d/2;
            if max(Y_diff) > 0.5 % traveled 0.5um away from border
                n_collisions = n_collisions + 1;
                col(n_collisions,:) = t;
            elseif (X(t) - X(prev_collision)) > 20 % travelled 20 um down border
                n_collisions = n_collisions + 1;
                col(n_collisions,:) = t;
            end
        end
    end 
   
%     % plot to watch tracks grow!
%     plot(X(1:t,:),Y(1:t,:)) 
%     if ~isnan(d) == 1
%         hold on
%         plot(tspan(1:t),ones(1,t)*d/2,'k--','LineWidth',2)
%         plot(tspan(1:t),ones(1,t)*-d/2,'k--','LineWidth',2)
%     end
%     xlabel('x position')
%     ylabel('y position')
%     title('Microtubule motion')
%     drawnow
%     pause(0.01)
end


% % trim zero rows
col = col(col ~= 0);
% 

end